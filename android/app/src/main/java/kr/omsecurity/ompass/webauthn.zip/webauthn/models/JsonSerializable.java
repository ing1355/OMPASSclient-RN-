package kr.omsecurity.ompass.webauthn.models;


public interface JsonSerializable {
    String toJson();
}
