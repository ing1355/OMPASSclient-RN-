package kr.omsecurity.ompass.webauthn.exceptions;

public class InvalidStateError extends WebAuthnException {
    public InvalidStateError() {
        super();
    }
}
