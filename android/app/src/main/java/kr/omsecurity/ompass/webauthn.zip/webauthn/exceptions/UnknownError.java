package kr.omsecurity.ompass.webauthn.exceptions;

public class UnknownError extends WebAuthnException {
    public UnknownError() {
        super();
    }
}
