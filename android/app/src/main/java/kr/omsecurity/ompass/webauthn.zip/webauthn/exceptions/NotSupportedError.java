package kr.omsecurity.ompass.webauthn.exceptions;

public class NotSupportedError extends WebAuthnException {
    public NotSupportedError() {
        super();
    }
}
