package kr.omsecurity.ompass.webauthn.models;

public class RpEntity {
    public String id;
    public String name;
}
