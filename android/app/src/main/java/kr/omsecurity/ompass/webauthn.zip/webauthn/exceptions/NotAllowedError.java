package kr.omsecurity.ompass.webauthn.exceptions;

public class NotAllowedError extends WebAuthnException {
    public NotAllowedError() {
        super();
    }
}
