package kr.omsecurity.ompass.webauthn.exceptions;

public class ConstraintError extends WebAuthnException {
    public ConstraintError() {
        super();
    }
}
