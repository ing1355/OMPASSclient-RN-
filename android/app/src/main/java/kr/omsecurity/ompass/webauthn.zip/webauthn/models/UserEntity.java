package kr.omsecurity.ompass.webauthn.models;

public class UserEntity {
    public byte[] id;
    public String displayName;
    public String name;
}
